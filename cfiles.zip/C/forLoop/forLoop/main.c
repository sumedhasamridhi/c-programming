//
//  main.c
//  forLoop
//
//  Created by igneus on 05/08/15.
//  Copyright © 2015 igneus. All rights reserved.
//

#include <stdio.h>

int main() {
    
    
    for (int value = 20; value > 10; value--) {
        printf("%d\n", value);
        
        
    }
    
    //getchar();
    return 0;
}
