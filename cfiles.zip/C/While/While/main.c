//
//  main.c
//  While
//
//  Created by igneus on 04/08/15.
//  Copyright © 2015 igneus. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int number = 5;
    
    while (number <= 55) {
        printf("%d\n", number);
        number++;
    }
    
    
    return 0;
}
