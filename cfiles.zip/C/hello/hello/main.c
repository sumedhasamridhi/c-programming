//
//  main.c
//  hello
//
//  Created by igneus on 21/07/15.
//  Copyright © 2015 igneus. All rights reserved.
//

#include <stdio.h>

int main(){
    // insert code here...
    //int High_Score = 1000;
    //High_Score = rating + feedback
    printf("Hello, igneus!\n");
    return 0;
}
