//
//  main.c
//  OddsInHundred
//
//  Created by igneus on 06/08/15.
//  Copyright © 2015 igneus. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    
    
    for (int oddy = 1; oddy <= 1000; oddy =  oddy+2 ) {
        printf("value is %d\n", oddy);
    }
    
    return 0;
}
