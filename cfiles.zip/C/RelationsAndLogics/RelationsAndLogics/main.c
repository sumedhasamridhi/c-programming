//
//  main.c
//  RelationsAndLogics
//
//  Created by igneus on 01/08/15.
//  Copyright © 2015 igneus. All rights reserved.
//

//This movie does not include any running code.


#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    int life = 10;
    int life2 = 10;
    
//    life == life2;
//    life != life2;
//    life <= life2
    
// logical AND    life && life2
// logical OR   life || life2
    
    return 0;
}
