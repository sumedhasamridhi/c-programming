//
//  main.c
//  FormatSpecifiers
//
//  Created by igneus on 01/08/15.
//  Copyright © 2015 igneus. All rights reserved.
//

#include <stdio.h>

int main() {
    
    int value = 10;
    double Double = 10.5;
    
    char Char = 'c';
    
    printf("%i\n %f\n %c\n", value, Double, Char);
    return 0;
}
