//
//  main.c
//  TypeDef
//
//  Created by igneus on 11/08/15.
//  Copyright © 2015 igneus. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    typedef int score;
    
    score playerOne = 10;
    
    printf("%d\n", playerOne);
    
    return 0;
}
