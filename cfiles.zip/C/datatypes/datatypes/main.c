//
//  main.c
//  datatypes
//
//  Created by igneus on 31/07/15.
//  Copyright © 2015 igneus. All rights reserved.
//

//Data Types in C
// Basic
//Enumerated
//void
//derived




#include <stdio.h>
#include "limits.h"

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Value for storage size of int : %d \n", sizeof(int));
    
    return 0;
}
